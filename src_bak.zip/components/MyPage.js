import Footer from './Footer';

function MyPage() {
	return (
		<>
			<div className="mypage">
				마이페이지에여
			</div>
			<Footer />
		</>
	)
}

export default MyPage