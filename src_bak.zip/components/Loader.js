import React from 'react';
function Loader() { 
	return ( 
	<div className ="loadBox">
		<div className="loader"></div>
		{/* <p class="loaderTxt">LODING...</p> */}
    </div> 
	); 
}

export default Loader;