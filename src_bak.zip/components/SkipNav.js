function SkipNav() {
	return (
		<a href="#main" className="skip_nav">본문 바로가기</a>
	)
}

export default SkipNav